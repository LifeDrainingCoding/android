package com.dblearning.a8lab;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.CheckBox;
import android.widget.LinearLayout;
import android.widget.ListView;

import java.util.ArrayList;
import java.util.Arrays;

public class Adapter extends ArrayAdapter<String> {
    private String[] listOfShizoProducts = {"Салат Арбузье","Оливковое масло","Чайный Грипп","Анансовая пицца","Велингтон","Кириешки","Водяра","Вискарик","Вермут","Яблоко"};
    public String[] choosedProducts = new String[10];


    private Context context;
    private ArrayList<String> items;

    public Adapter(Context context,ArrayList<String> items) {
        super(context, R.layout.item, items);
        this.context = context;
        this.items = items;

    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        View view = convertView;
        if (view == null) {
            LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            view = inflater.inflate(R.layout.item, parent, false);
        }



        CheckBox checkBox = (CheckBox) view.findViewById(R.id.checkBox);
        checkBox.setText(items.get(position));
        checkBox.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                    if (checkBox.isChecked()) {
                        update(position,items.get(position));
                    } else {
                        remove(position);

                    }
                }

        });




        return view;
    }
    private void update(int i, String s){

        choosedProducts[i] = s;
        findNulls();
        MainActivity.totallProducts.setText(Arrays.deepToString(choosedProducts));
    }
    private  void remove (int i){
        choosedProducts[i] = "";
        findNulls();
        MainActivity.totallProducts.setText(Arrays.deepToString(choosedProducts));
    }
    private void findNulls(){

            for (int i = 0; i<choosedProducts.length; i++){
                if (choosedProducts[i] == null){
                    choosedProducts[i]= "";
            }



            }
        }


    }



