package com.dblearning.a8lab;

import android.content.Intent;
import android.view.View;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;

import java.util.ArrayList;
import java.util.Arrays;

public class MainActivity extends AppCompatActivity {
    private ArrayList<String> listOfShizoProducts;
    private String[] list = {"Салат Арбузье","Оливковое масло","Чайный Грипп","Анансовая пицца","Велингтон","Кириешки","Водяра","Вискарик","Вермут","Яблоко"};

    private String[] choosedProducts = new String[9];

public static TextView totallProducts;

private Button nextBtn;
private ListView listView;
private ArrayList<CheckBox> checkBoxes;


public  Adapter adapter;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        listOfShizoProducts = new ArrayList<>();
        listOfShizoProducts.addAll(Arrays.asList(list));
        totallProducts = findViewById(R.id.totall_products);
        nextBtn = findViewById(R.id.next_btn);
        listView = findViewById(R.id.list_view);
        checkBoxes = new ArrayList<>();
        adapter =  new Adapter(this,listOfShizoProducts);
        listView.setAdapter(adapter);
        nextBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
               sendData();
            }
        });

    }
    private void sendData(){
        Intent intent = new Intent(this, MainActivity2.class);

        for (int i = 0; i< adapter.choosedProducts.length;i++){

            intent.putExtra(String.valueOf(i),adapter.choosedProducts[i]);
        }
        startActivity(intent);

    }
    public boolean CheckForEmpty(){
        if(totallProducts.getText().toString().isEmpty()   ){
            nextBtn.setEnabled(true);


                }else {

                    for(int i = 0; i<adapter.choosedProducts.length;i++){
                        if (adapter.choosedProducts[i].isEmpty()){
                            Toast.makeText(this,"Выбери хоть что-то", Toast.LENGTH_LONG);
                            nextBtn.setEnabled(false);
                            return true;

                }
            }
        }
        return false;
    }


}