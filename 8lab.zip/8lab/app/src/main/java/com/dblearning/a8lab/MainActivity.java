package com.dblearning.a8lab;

import android.view.View;
import android.view.ViewGroup;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {
 private ArrayList<CheckBox> checkBoxes;
private TextView totallProducts;

private Button nextBtn;
private ListView listView;
private String[] listOfShizoProducts = {"Салат Арбузье","Оливковое масло","Чайный Грипп","Анансовая пицца","Велингтон","Кириешки","Водяра","Вискарик","Вермут","Яблоко"};
private ArrayAdapter<String> adapter;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        checkBoxes = new ArrayList<>();
        totallProducts = findViewById(R.id.totall_products);
        nextBtn = findViewById(R.id.next_btn);
        listView = findViewById(R.id.list_view);
        adapter = new ArrayAdapter<>(this,R.layout.item,listOfShizoProducts);
        for (int i = 0; i < adapter.getCount(); i++) {
            View view = adapter.getView(i, null, listView);
            CheckBox checkbox = new CheckBox(this);
            //android.R.layout.simple_list_item_1
            checkbox.setLayoutParams(new LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT));
            checkbox.setPadding(10, 10, 10, 10);
            checkBoxes.add(checkbox);
            checkBoxes.get(i).setText("");
            checkBoxes.get(i).setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    //for() must be
                    if ()
                }
            });
            listView.addView(view);
        }
    }
}