package com.dblearning.a8lab;

import android.content.Intent;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;

import java.util.ArrayList;

public class MainActivity2 extends AppCompatActivity {
    ArrayList<String> data;
    ListView listView;
    Button buyBtn;

     private  ArrayAdapter<String> adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

        data = new ArrayList<>();
        getData();
        adapter  =  new ArrayAdapter<String>(this,R.layout.item2,R.id.textView,data);
        listView = findViewById(R.id.listView2);
        listView.setAdapter(adapter);
        buyBtn =  findViewById(R.id.buy_btn);
        buyBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(view.getContext(),"ВЫ КУПИЛИ СЛОНА!!!!",Toast.LENGTH_SHORT).show();
            }
        });


    }
    private void getData(){
        Intent intent = getIntent();
        for (int i = 0; i<10; i++){
            data.add(intent.getStringExtra(String.valueOf(i)));
        }
    }
}