package com.kursach.ckursach;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;

public class List_Of_Avaible_Tabs extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_list_of_avaible_tabs);
    }
}