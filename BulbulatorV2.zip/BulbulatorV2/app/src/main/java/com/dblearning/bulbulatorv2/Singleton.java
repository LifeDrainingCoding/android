package com.dblearning.bulbulatorv2;

public class Singleton {
    private static Singleton instance;
    private String num1,num2;

    private Singleton() {}

    public static Singleton getInstance() {
        if (instance == null) {
            instance = new Singleton();
        }
        return instance;
    }

    public String getNum1() {
        return num1;
    }
    public String getNum2() {
        return num2;
    }

    public void setNum1(String num1) {
        this.num1 = num1;
    }
    public void setNum2(String data) {
        this.num2 = data;
    }
}
//to use
// DataHolder.getInstance().setData("value");  сохранение данных в Singleton
//String value = DataHolder.getInstance().getData(); // получение данных