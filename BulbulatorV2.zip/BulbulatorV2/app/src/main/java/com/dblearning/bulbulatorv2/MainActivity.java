package com.dblearning.bulbulatorv2;

import android.widget.Button;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;

public class MainActivity extends AppCompatActivity {
    Button zeroBtn,oneBtn,twoBtn,threeBtn,fourBtn,fiveBtn,sixBtn,sevenBtn,eightBtn,nineBtn,divideBtn,multiplyBtn,plusBtn,minusBtn,
            clearBtn,equalsBtn, undoBtn;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        zeroBtn = findViewById(R.id.zero);
        oneBtn = findViewById(R.id.one);
        twoBtn = findViewById(R.id.two);
        threeBtn = findViewById(R.id.three);
        fourBtn= findViewById(R.id.four);
        fiveBtn= findViewById(R.id.five);
        sixBtn= findViewById(R.id.six);
        sevenBtn= findViewById(R.id.seven);
        eightBtn= findViewById(R.id.eight);
        nineBtn= findViewById(R.id.nine);
        divideBtn= findViewById(R.id.divide);
        multiplyBtn= findViewById(R.id.multiply);
        plusBtn= findViewById(R.id.plus);
        minusBtn= findViewById(R.id.minus);
        clearBtn=findViewById(R.id.clear);
        equalsBtn=findViewById(R.id.equals);
        undoBtn=findViewById(R.id.undo);
    }
}