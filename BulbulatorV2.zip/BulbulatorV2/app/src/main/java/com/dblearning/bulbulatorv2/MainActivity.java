package com.dblearning.bulbulatorv2;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;
import java.util.Arrays;

public class MainActivity extends AppCompatActivity {
    String firstNumber;
    String secondNumber;
    String tempOperation;
    Button zeroBtn,oneBtn,twoBtn,threeBtn,fourBtn,fiveBtn,sixBtn,sevenBtn,eightBtn,nineBtn,divideBtn,multiplyBtn,plusBtn,minusBtn,
            clearBtn,equalsBtn,more_optionsBtn;
    ImageButton undoBtn;
    TextView firstNumberTxtView, secondNumberTxtView, currentOperationTxtview;
    Intent intent;
boolean isUserSmart = false;






    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        firstNumberTxtView =findViewById(R.id.firstNumber);
        secondNumberTxtView = findViewById(R.id.secondNumber);
        currentOperationTxtview=findViewById(R.id.currentOperation);
        zeroBtn = findViewById(R.id.zero);
        oneBtn = findViewById(R.id.one);
        twoBtn = findViewById(R.id.two);
        threeBtn = findViewById(R.id.three);
        fourBtn= findViewById(R.id.four);
        fiveBtn= findViewById(R.id.five);
        sixBtn= findViewById(R.id.six);
        sevenBtn= findViewById(R.id.seven);
        eightBtn= findViewById(R.id.eight);
        nineBtn= findViewById(R.id.nine);
        divideBtn= findViewById(R.id.divide);
        multiplyBtn= findViewById(R.id.multiply);
        plusBtn= findViewById(R.id.plus);
        minusBtn= findViewById(R.id.minus);
        clearBtn=findViewById(R.id.clear);
        equalsBtn=findViewById(R.id.equals);
        undoBtn=findViewById(R.id.undo);
        more_optionsBtn =findViewById(R.id.more_options);
        tempOperation = "";
        firstNumber ="";
        secondNumber ="";
        intent = new Intent(this, ExtendedFeaturesActivity.class);
        more_optionsBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {



                    Singleton.getInstance().setNum1(firstNumber);
                Singleton.getInstance().setNum2(secondNumber);

                startActivity(intent);
            }
        });



        clearBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                firstNumber = "";
                secondNumber = "";
                tempOperation = "";
                updateTxtViews();
            }
        });

        undoBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                ArrayList<String> tempArray;
                if (secondNumber!=null && !secondNumber.equals("")   ){
                    tempArray = new ArrayList<>(Arrays.asList( secondNumber.split("")));
                    tempArray.remove (tempArray.size()-1);
                     secondNumber= String.join("",tempArray);
                    updateTxtViews();


                }else if(!tempOperation.equals("")){
                    tempOperation = "";
                    updateTxtViews();

                } else if (!firstNumber.equals("")) {
                    tempArray = new ArrayList<>(Arrays.asList(firstNumber.split("")));
                    tempArray.remove (tempArray.size()-1);
                    firstNumber = String.join("",tempArray);
                    updateTxtViews();
                }else{
                    Toast.makeText(view.getContext(), "А ты че стирать собрался?",Toast.LENGTH_LONG ).show();
                }

            }
        });
    }

    public void onClickNumbers(View view){
        Button button = (Button) view;
        if( tempOperation.isEmpty()|| tempOperation.equals("")){


         if(firstNumber == null || firstNumber.equals("")){



             firstNumber = button.getText().toString();
             System.out.println(firstNumber);
             firstNumber = checkForSmartPeople(firstNumber);
             updateTxtViews();


         }else{
         firstNumber = firstNumber + button.getText().toString();
         System.out.println(firstNumber);
         firstNumber = checkForSmartPeople(firstNumber);
             updateTxtViews();
             }
        }else {
            if (secondNumber == null || secondNumber.equals("")){
              secondNumber = button.getText().toString();
              System.out.println(secondNumber);
              secondNumber = checkForSmartPeople(secondNumber);
                updateTxtViews();
            }else{
                secondNumber = secondNumber + button.getText().toString();
                System.out.println(secondNumber);
                secondNumber = checkForSmartPeople(secondNumber);
                updateTxtViews();
            }
        }
    }
    public void onClickOperation(View view){
        Button button =  (Button) view;
        if (tempOperation== null|| tempOperation.equals("") || tempOperation.isEmpty()){


            tempOperation = button.getText().toString();
            updateTxtViews();
        }else{
            firstNumber = calculation(firstNumber,secondNumber,tempOperation);
            secondNumber= "";
            tempOperation = button.getText().toString();
            updateTxtViews();
        }
        }



    public void onClickCalculation(View view){
        Button button=  (Button) view;
        if(button.getText().toString().equals("=") & !tempOperation.equals("")  ){
            firstNumber =  calculation(firstNumber,secondNumber,tempOperation);
            secondNumber = "";
            tempOperation="";
            updateTxtViews();
        }
    }


    public String calculation(String firstNumber,String secondNumber, String tempOperation) {

        String string = "";

        try {
            double number1 = Double.parseDouble(firstNumber);
            double number2 = Double.parseDouble(secondNumber);
            double equaledNumber = 0;


            switch (tempOperation) {
                case "*":
                    equaledNumber = number1 * number2;
                    string = String.valueOf(equaledNumber);
                    break;
                case "/":
                    equaledNumber = number1 / number2;
                    string = String.valueOf(equaledNumber);
                    break;
                case "+":
                    equaledNumber = number1 + number2;
                    string = String.valueOf(equaledNumber);
                    break;
                case "-":
                    equaledNumber = number1 - number2;
                    string = String.valueOf(equaledNumber);
                    break;

                default:
                    Toast.makeText(this, "Умно.", Toast.LENGTH_SHORT).show();
                    break;
            }
        }catch (NullPointerException ex){
            Toast.makeText(this, "А ты че считать собрался?",Toast.LENGTH_LONG).show();
        }


        return string;
    }
    public String checkForSmartPeople(String number){
        String[] checkArray = number.split("");
        if( checkArray[0].equals(".") ) {
            Toast.makeText(this, "Ага щас... Введи число, а не просто точку",Toast.LENGTH_LONG ).show();
           number = "";
           return number;
        }else {
            return number;
        }
    }
    public void updateTxtViews(){
        firstNumberTxtView.setText(firstNumber);
        secondNumberTxtView.setText(secondNumber);
        currentOperationTxtview.setText(tempOperation);
    }

    @Override
    protected void onPause() {
        super.onPause();


        }


    @Override
    protected void onResume() {
        super.onResume();
        try {


           firstNumber =  Singleton.getInstance().getNum1();
           secondNumber = Singleton.getInstance().getNum2();
            updateTxtViews();

        }catch (NullPointerException ex){
            System.out.println("Проебался где-то");
        }

    }
}