package com.dblearning.bulbulatorv2;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;
import java.util.Arrays;

public class MainActivity extends AppCompatActivity {
    String firstNumber;
    String secondNumber;
    String tempOperation;
    Button zeroBtn,oneBtn,twoBtn,threeBtn,fourBtn,fiveBtn,sixBtn,sevenBtn,eightBtn,nineBtn,divideBtn,multiplyBtn,plusBtn,minusBtn,
            clearBtn,equalsBtn;
    ImageButton undoBtn;
    TextView firstNumberTxtView, secondNumberTxtView, currentOperationTxtview;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        firstNumberTxtView =findViewById(R.id.firstNumber);
        secondNumberTxtView = findViewById(R.id.secondNumber);
        currentOperationTxtview=findViewById(R.id.currentOperation);
        zeroBtn = findViewById(R.id.zero);
        oneBtn = findViewById(R.id.one);
        twoBtn = findViewById(R.id.two);
        threeBtn = findViewById(R.id.three);
        fourBtn= findViewById(R.id.four);
        fiveBtn= findViewById(R.id.five);
        sixBtn= findViewById(R.id.six);
        sevenBtn= findViewById(R.id.seven);
        eightBtn= findViewById(R.id.eight);
        nineBtn= findViewById(R.id.nine);
        divideBtn= findViewById(R.id.divide);
        multiplyBtn= findViewById(R.id.multiply);
        plusBtn= findViewById(R.id.plus);
        minusBtn= findViewById(R.id.minus);
        clearBtn=findViewById(R.id.clear);
        equalsBtn=findViewById(R.id.equals);
        undoBtn=findViewById(R.id.undo);
        tempOperation = "";
        firstNumber ="";
        secondNumber ="";
        clearBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                firstNumber = "";
                secondNumber = "";
                tempOperation = "";
                updateTxtViews();
            }
        });

        undoBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                ArrayList<String> tempArray;
                if (!secondNumber.equals("")){
                    tempArray = new ArrayList<>(Arrays.asList( secondNumber.split("")));
                    tempArray.remove (tempArray.size()-1);
                     secondNumber= String.join("",tempArray);
                    updateTxtViews();


                }else if(!tempOperation.equals("")){
                    tempOperation = "";
                    updateTxtViews();

                } else if (!firstNumber.equals("")) {
                    tempArray = new ArrayList<>(Arrays.asList(firstNumber.split("")));
                    tempArray.remove (tempArray.size()-1);
                    firstNumber = String.join("",tempArray);
                    updateTxtViews();
                }

            }
        });
    }

    public void onClickNumbers(View view){
        Button button = (Button) view;
        if( !tempOperation.isEmpty()|| !tempOperation.equals("")){


         if(firstNumber == null || firstNumber.equals("")){



             firstNumber = button.getText().toString();
             System.out.println(firstNumber);
             firstNumber = checkForSmartPeople(firstNumber);
             updateTxtViews();


         }else{
         firstNumber = firstNumber + button.getText().toString();
         System.out.println(firstNumber);
         firstNumber = checkForSmartPeople(firstNumber);
             updateTxtViews();
             }
        }else {
            if (secondNumber == null || secondNumber.equals("")){
              secondNumber = button.getText().toString();
              System.out.println(secondNumber);
              secondNumber = checkForSmartPeople(secondNumber);
                updateTxtViews();
            }else{
                secondNumber = secondNumber + button.getText().toString();
                System.out.println(secondNumber);
                secondNumber = checkForSmartPeople(secondNumber);
                updateTxtViews();
            }
        }
    }
    public void onClickOperation(View view){
        Button button =  (Button) view;
        if (tempOperation== null|| tempOperation.equals("") || tempOperation.isEmpty()){


            tempOperation = button.getText().toString();
            updateTxtViews();
        }else{
            firstNumber = calculation(firstNumber,secondNumber,tempOperation);
            secondNumber= "";
            tempOperation = button.getText().toString();
            updateTxtViews();
        }
        }



    public void onClickCalculation(View view){
        Button button=  (Button) view;
        if(button.getText().toString().equals("=") & !tempOperation.equals("")  ){
            firstNumber = calculation(firstNumber,secondNumber,tempOperation);
            secondNumber = "";
            tempOperation="";
            updateTxtViews();
        }
    }


    public String calculation(String firstNumber,String secondNumber, String tempOperation){

        double number1 =  Double.parseDouble(firstNumber);
        double number2= Double.parseDouble(secondNumber);
        double equaledNumber = 0;
        String string = "";

        switch (tempOperation){
            case "*": equaledNumber =number1*number2;
            string = String.valueOf(equaledNumber);
             break;
            case "/": equaledNumber =number1/number2;
                string = String.valueOf(equaledNumber);
             break;
            case "+":  equaledNumber =number1+number2;
                string = String.valueOf(equaledNumber);
                 break;
            case "-": equaledNumber =number1-number2;
                string = String.valueOf(equaledNumber);
                break;

            default: Toast.makeText(this, "Умно." ,Toast.LENGTH_SHORT).show();  break;

        }
        return string;
    }
    public String checkForSmartPeople(String number){
        String[] checkArray = number.split("");
        if( checkArray[0].equals(".") ) {
            Toast.makeText(this, "Ага щас... Введи число, а не просто точку",Toast.LENGTH_LONG ).show();
           number = "";
           return number;
        }else {
            return number;
        }
    }
    public void updateTxtViews(){
        firstNumberTxtView.setText(secondNumber);
        secondNumberTxtView.setText(firstNumber);
        currentOperationTxtview.setText(tempOperation);
    }
}