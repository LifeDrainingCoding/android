package com.dblearning.bulbulatorv2;

import android.app.Activity;
import android.content.Intent;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Spinner;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;

public class ExtendedFeaturesActivity extends AppCompatActivity {
    static Activity activity;
    Spinner left, right;
    String tempNumber1,tempNumber2,number1,number2;
    TextView num1,num2;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_extended_features);
        activity = this;
        num1 = findViewById(R.id.textViewNumber1);
        num2 = findViewById(R.id.textViewNumber2);
        left = findViewById(R.id.spinnerOperationLeft);
        right = findViewById(R.id.spinnerOperationRight);
        ArrayAdapter<?> arrayAdapter = ArrayAdapter.createFromResource(this, R.array.operations, androidx.appcompat.R.layout.support_simple_spinner_dropdown_item);
        left.setAdapter(arrayAdapter);
        right.setAdapter(arrayAdapter);

        number1 = "";
        number2 = "";
        number1 = Singleton.getInstance().getNum1();
        number2 = Singleton.getInstance().getNum2();
        tempNumber1 = "";
        tempNumber2 = "";


        left.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                                           @Override
                                           public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                                               try {


                                                   tempNumber1 = calculate(i, number1);

                                                   updateTxtViews();
                                               }catch (NullPointerException ex){
                                                   ex = new NullPointerException("Нет числа");
                                                   tempNumber1 = ex.getLocalizedMessage();
                                                   left.setEnabled(false);
                                                   updateTxtViews();
                                               }
                                           }

                                           @Override
                                           public void onNothingSelected(AdapterView<?> adapterView) {

                                           }
                                       });
                right.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                    @Override
                    public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                        try {


                        tempNumber2 = calculate(i, number2);

                        updateTxtViews();}catch (NullPointerException ex){
                            ex = new NullPointerException("Нет числа");
                            tempNumber2 = ex.getLocalizedMessage();
                            right.setEnabled(false);
                            updateTxtViews();
                        }
                    }

                    @Override
                    public void onNothingSelected(AdapterView<?> adapterView) {

                    }
                });

    }
    public String calculate(int i, String number){
        String equaledNumber;
        if(!number.equals("")){

            double temp = Double.parseDouble(number);

            switch (i){
                case 0:  equaledNumber = number; return equaledNumber ;
                case 1:  equaledNumber = String.valueOf(Math.sin(temp)) ; return equaledNumber;
                case 2:  equaledNumber = String.valueOf(Math.cos(temp)) ; return equaledNumber;
                case 3:  equaledNumber = String.valueOf(Math.tan(temp)) ; return equaledNumber;
                case 4:  equaledNumber = String.valueOf(Math.atan(temp)) ; return equaledNumber;
                case 5:  equaledNumber = String.valueOf(Math.pow(temp,2)) ; return equaledNumber;
                case 6:  equaledNumber = String.valueOf(Math.sqrt(temp)) ; return equaledNumber;
                default: return "";

            }

}else{
            return number;
        }
    }
    public void updateTxtViews(){
        num1.setText(tempNumber1);
        num2.setText(tempNumber2);
    }
    public void sendDataBack(View view){
       Singleton.getInstance().setNum1(tempNumber1);
       Singleton.getInstance().setNum2(tempNumber2);
        finish();
    }
}