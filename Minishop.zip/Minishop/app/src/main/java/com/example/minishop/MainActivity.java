package com.example.minishop;

import android.content.Intent;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;

import java.util.ArrayList;
import java.util.Arrays;

public class MainActivity extends AppCompatActivity {
    private TextView textView;
    private  String[] Text = new String[] {"","","","","","","","","","","",""};
    private int index = 0;
    private Button next;
    private static final int[] checkBoxID = {
        R.id.checkBox4,
            R.id.checkBox5,
            R.id.checkBox6,
            R.id.checkBox7,
            R.id.checkBox8,
            R.id.checkBox9,
            R.id.checkBox10,
            R.id.checkBox11,
            R.id.checkBox12,
            R.id.checkBox13,
            R.id.checkBox14,
            R.id.checkBox15,

    };
 private ArrayList<CheckBox> checkBoxes;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        checkBoxes = new ArrayList<CheckBox>();
        textView = findViewById(R.id.textView);
        next = findViewById(R.id.button);





            for (int i = 0 ; i <12; i++){
                CheckBox checkBox =(CheckBox) findViewById(checkBoxID[i]);
                checkBoxes.add(checkBox);
                checkBoxes.get(i).setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        for (int i = 0; i<12;i++){
                        if (checkBoxes.get(i).isChecked()) {
                                update(i, checkBoxes.get(i).getText().toString());


                        } else {

                            remove(i);

                        }
                        }
                    }
                });

            }
            next.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    onClik();
                }
            });


    }
    private void update(int i, String s){
        Text[i] = s;
        textView.setText(Arrays.deepToString(Text));
    }
    private void onClik() {

        Intent intent = new Intent(this, ShowAllItems.class );
        for (int i = 0 ; i<12; i++){
        intent.putExtra(String.valueOf(i), Text[i]);
        }
        startActivity(intent);

    }
    private  void remove (int i){
        Text[i] = "";
        textView.setText(Arrays.deepToString(Text));
    }
}