package com.example.minishop;

import android.content.Intent;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;

import java.util.ArrayList;

public class ShowAllItems extends AppCompatActivity {
    private static int firstColumn[] = {
      R.id.textView41,
            R.id.textView42,
            R.id.textView43,
            R.id.textView44,
            R.id.textView45,
            R.id.textView46,
            R.id.textView47,
            R.id.textView48,
            R.id.textView49,
            R.id.textView60,
            R.id.textView61,
            R.id.textView62

    };
    private static int secondColumn[] = {
            R.id.textView51,
            R.id.textView52,
            R.id.textView53,
            R.id.textView54,
            R.id.textView55,
            R.id.textView56,
            R.id.textView57,
            R.id.textView58,
            R.id.textView59,
            R.id.textView70,
            R.id.textView71,
            R.id.textView72

    };
    private ArrayList <TextView> textViews;
    private ArrayList <TextView> textViews1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_show_all_items);
        textViews = new ArrayList<TextView>();
        textViews1 = new ArrayList<TextView>();
        Intent intent = getIntent();
        for (int i = 0; i<12; i++){

                TextView textView = findViewById(secondColumn[i]);
                TextView textView1 = findViewById(firstColumn[i]);
                textViews.add(textView);
                textViews1.add(textView1);
                textViews1.get(i).setText(String.valueOf(i));
                textViews.get(i).setText(intent.getStringExtra(String.valueOf(i)));

        }

    }
}