package com.dblearning.molemash;

import android.annotation.SuppressLint;
import android.net.wifi.p2p.WifiP2pManager;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

import java.util.EventListener;
import java.util.Timer;
import java.util.TimerTask;

public class EventTimer  {
    private final static float CLICK_DRAG_TOLERANCE = 10; // Often, there will be a slight, unintentional, drag when the user taps the FAB, so we need to account for this.

    private float downRawX, downRawY;
    private float dX, dY;
Timer timer;
TimerTask timerTask;
long delay;
ImageView  imageView;
    EventListener eventListener;
    boolean bombMissed=false;
   @SuppressLint("ClickableViewAccessibility")
   public EventTimer( int difficulty, ImageView draggableImage ){


       this.timerTask =timerTask;
       switch (difficulty){
           case 1: delay = 100 ; break;
           case 2: delay = 90 ;break;
           case 3: delay = 80;break;
           case 4: delay = 70 ;break;
           case 5: delay = 60;break;
           case 6: delay = 50;break;
           case 7: delay = 40;break;
           case 8: delay = 30;break;
           case 9: delay = 20;break;
           case 10: delay = 10;break;
           default: delay =100;break;


       }
       this.imageView = draggableImage;
       imageView.setOnTouchListener(new View.OnTouchListener() {
           @Override
           public boolean onTouch(View v, MotionEvent event) {

               switch (event.getAction()) {
                   case MotionEvent.ACTION_DOWN:



                   case MotionEvent.ACTION_MOVE:
                       // Calculate the distance moved
                       float dx = event.getX() ;
                       float dy = event.getY() ;

                       // Update the image view's position
                       imageView.setX(imageView.getX() + dx - imageView.getWidth()/2);
                       imageView.setY(imageView.getY() + dy  - imageView.getHeight()/2);



                       break;
                   case MotionEvent.ACTION_UP:
                       imageView.performClick();
               }

               return true;
           }
       });
   }

   public void start( TimerTask timerTask){
       Timer timer = new Timer();

       timer.schedule(timerTask, delay, delay);





   }




}
