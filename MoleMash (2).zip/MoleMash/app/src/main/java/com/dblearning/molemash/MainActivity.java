package com.dblearning.molemash;

import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.media.MediaPlayer;
import android.os.Looper;
import android.widget.ImageView;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import androidx.core.util.Consumer;

import java.io.IOException;
import java.util.EventListener;
import java.util.Random;
import java.util.TimerTask;

public class MainActivity extends AppCompatActivity {
public ImageView mole;
    public static ImageView field;
    public static ImageView bomb;


private TimerTask timerTask;
private int difficulty = 10;
int counter = -1;
private boolean bombMissed = false;
private boolean moleDied = false;
boolean isStopped = false;

    MediaPlayer mediaPlayer;

    @SuppressLint("ClickableViewAccessibility")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        mole = findViewById(R.id.moleImg);
        field = findViewById(R.id.fieldImg);
        bomb = findViewById(R.id.bombImg);
        EventTimer eventTimer = new EventTimer(difficulty,mole);
        mediaPlayer = MediaPlayer.create(this, R.raw.explosion);

        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Игра кончена")
                .setMessage("Ваш счет:"+counter)
                .setNegativeButton("Выйти", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        finish();
                    }
                })
                .setPositiveButton("Начать снова", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        moleDied = false;
                        bombMissed = true;
                        dialog.cancel();
                    }
                }).create();


        timerTask = new TimerTask() {
            @Override
            public void run() {

    if(bombMissed == true){
        bombMissed= false;
        float temp = Float.valueOf(field.getWidth()) + field.getX();
    bomb.setY(field.getY()+100);
    bomb.setX(nextFloatBetween2(field.getX(),temp-bomb.getWidth()));


    }else {
        if(moleDied ==false) {
            float tempY = bomb.getY() + 5;
            bomb.setY(tempY);
        }

        for(int i = 0 ; i<getBomb().getHeight() ; i++){
            if (getBomb().getY()+i>=getField().getY()+getField().getHeight() ){

                try {
                    playExplosion();
                } catch (IOException e) {
                    throw new RuntimeException(e);
                }
                counter = counter+1;
                bombMissed = true;
            }
            for(int j =0; j<getBomb().getWidth();j++){

                if(Math.round(getBomb().getY()+i)==Math.round(mole.getY()+i) || Math.round(getBomb().getX()-j)==Math.round(mole.getX()-j)){
                    try {
                        playExplosion();
                    } catch (IOException e) {
                        throw new RuntimeException(e);
                    }
                    moleDied = true;

                    builder.show();
                    break;
                }

            }
            if (moleDied == true){
                break;
            }
        }
    }
            }
        };

        eventTimer.start(timerTask);


    }
    public  void playExplosion() throws IOException {


       if (mediaPlayer.isPlaying()){
           mediaPlayer.seekTo(0);
       }
        mediaPlayer.setVolume(100f,100f);
        mediaPlayer.start();








    }
    public static ImageView getBomb(){
        return bomb;
    }
    public static ImageView getField(){
        return field;
    }
    public  float nextFloatBetween2(float min, float max) {
        return (new Random().nextFloat() * (max - min)) + min;
    }
}