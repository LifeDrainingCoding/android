package com.kursach.fitnessapp;


import android.content.Context;
import android.content.SharedPreferences;
import android.net.Uri;
import android.widget.Toast;
import com.google.gson.Gson;
import com.google.gson.annotations.SerializedName;
import org.jetbrains.annotations.NotNull;


import java.lang.reflect.Array;
import java.util.*;

public class Singleton {
     static Context context;




    private static Singleton instance;
   final Uri[] uri = new Uri[]{
            Uri.parse("android.resource://" + context.getPackageName() + "/" + R.raw.adjusting_the_blades),
            Uri.parse("android.resource://" + context.getPackageName() + "/" + R.raw.adjusting_the_blades_by_lifting_dumbells),
            Uri.parse("android.resource://" + context.getPackageName() + "/" + R.raw.calf_stretching),
            Uri.parse("android.resource://" + context.getPackageName() + "/" + R.raw.hand_reduction_with_dumbells),
            Uri.parse("android.resource://" + context.getPackageName() + "/" + R.raw.just_chillin),
            Uri.parse("android.resource://" + context.getPackageName() + "/" + R.raw.just_hanging_around),
            Uri.parse("android.resource://" + context.getPackageName() + "/" + R.raw.lifting),
            Uri.parse("android.resource://" + context.getPackageName() + "/" + R.raw.lunges),
            Uri.parse("android.resource://" + context.getPackageName() + "/" + R.raw.pull_ups),
            Uri.parse("android.resource://" + context.getPackageName() + "/" + R.raw.pull_ups_dumbells),
            Uri.parse("android.resource://" + context.getPackageName() + "/" + R.raw.pull_ups_side_by_side),




            Uri.parse("android.resource://" + context.getPackageName() + "/" + R.raw.pull_ups_while_half_laying),
            Uri.parse("android.resource://" + context.getPackageName() + "/" + R.raw.pull_ups_while_sitting),
            Uri.parse("android.resource://" + context.getPackageName() + "/" + R.raw.push_ups_laying_with_dumbells),
            Uri.parse("android.resource://" + context.getPackageName() + "/" + R.raw.push_ups_with_dumbells),
            Uri.parse("android.resource://" + context.getPackageName() + "/" + R.raw.raising_hands),
            Uri.parse("android.resource://" + context.getPackageName() + "/" + R.raw.sit_downs_with_dumbells),
            Uri.parse("android.resource://" + context.getPackageName() + "/" + R.raw.sport_dance),
            Uri.parse("android.resource://" + context.getPackageName() + "/" + R.raw.sport_jumps),
            Uri.parse("android.resource://" + context.getPackageName() + "/" + R.raw.sport_kicks),
            Uri.parse("android.resource://" + context.getPackageName() + "/" + R.raw.step_ups_with_dumbells),
            Uri.parse("android.resource://" + context.getPackageName() + "/" + R.raw.walking_with_dumbells)
    };
    private ArrayList<Uri> currentPaths = new ArrayList<>();
    private ArrayList<String> currentNames = new ArrayList<>();
    private int numberOfDays;
    private int currentDay;
     private static final int P1itmes = 10 ;

    public int getTimeLimit() {
        return timeLimit;
    }

    public void setTimeLimit(int timeLimit) {
        this.timeLimit = timeLimit;
    }

    private int timeLimit;

    public int getRestTime() {
        return restTime;
    }

    public void setRestTime(int restTime) {
        this.restTime = restTime;
    }

    public int getIterator() {
        return iterator;
    }

    public void incIterator() {
        this.iterator = iterator+1;
    }

    private int iterator = 0;

    private int restTime;
    private String thisPath;
    private  final ArrayList<Uri> allPaths = new ArrayList<Uri>(){
        {
            this.addAll(Arrays.asList(uri));
        }
    };




@SerializedName("workout")
   private ArrayList<HashMap<String,Uri>> workoutList = new ArrayList<>();

    public boolean isFinishedConf() {
        return isFinishedConf;
    }

    public void setFinishedConf(boolean finishedConf) {
        isFinishedConf = finishedConf;
    }

    private boolean isFinishedConf = false;


   private HashMap<String,Uri> currentWorkoutToday = new HashMap<>();
   @NotNull
   private HashMap<Integer, Boolean > isCompletedDaysMap = new HashMap<Integer,Boolean>();
    private final ArrayList<String> namesOfExcercies = new ArrayList<String>(){
        {
            add("Сведение лопаток");
            add("Сведение лопаток гантелями");
            add("Растягивание голени");
            add("Сведение рук с гантелями");
            add("Отдых");
            add("Походите/Погуляйте");
            add("Лифтинг гантелей");
            add("Выпады");
            add("Подтягивание на турнике");
            add("Подтягивание гантелей");
            add("Подтягивание из бока в бок");
            add("Подтягивание полу-лежа");
            add("Подтягивание сидя");
            add("Жим гантелей лежа");
            add("Жим гантелей");
            add("Развод рук в стороны");
            add("Присяды с гантелями");
            add("Спортивный танец");
            add("Спортивные прыжки");
            add("Спортивные пинки");
            add("Шаги вверх с гантелями");
            add("Ходьба с гантелями");
        }
    };






    public static Singleton getInstance(Context context1) {
context = context1;
        if(context!=null){
            if (instance == null) {
                instance = new Singleton();
            }




            return instance;}else {
            throw new NullPointerException("Синглтону не задан контекст в:"+ Singleton.class.getSimpleName());
        }
    }

    public void configureDay(){

    }
    public int getNumOfDays() {
        return numOfDays;
    }

    public void setNumOfDays(int numOfDays) {
        this.numOfDays = numOfDays;
    }


    private int numOfDays = -1;

    public Uri getPathById(int i){
        return allPaths.get(i);
    }

    public ArrayList<Uri> getAllPaths(){
        return allPaths;
    }

    public void addNameToCustomNamesList(String name){
        currentNames.add(name);
    }
    public void clearCustomNames(){
        currentNames.clear();
    }
    public String getCustomNameById(int id){
        return currentNames.get(id);
    }
    public void undoLastCustomName(){
        currentNames.remove(currentNames.size()-1);
    }


    public void  addPathToCurrentPaths( Uri uri){


        currentPaths.add(uri);
    }
    public String getCurrentPathById(int id){
      return   currentPaths.get(id).getPath();
    }
    public void clearCurrentPaths(){
        currentPaths = new ArrayList<Uri>();
    }
    public void  initMapOfDays(){
        if (isCompletedDaysMap.isEmpty()) {
            for (int i = 0; i < workoutList.size(); i++) {
                isCompletedDaysMap.put(i, false);
            }
        }
    }
    public void clearMapOfDays(){
        isCompletedDaysMap.clear();
    }
    public void setFlagToMapItem(int day, boolean isCompleted){
        isCompletedDaysMap.put(day, isCompleted);

    }

    public Boolean isCompletedToday(int day){
        if(day<isCompletedDaysMap.size()) {
            return isCompletedDaysMap.get(day).booleanValue();
        }else {
            Toast.makeText(context, "Данила ты что крейзи? Откуда ты взял несуществующий день? ", Toast.LENGTH_LONG).show();
            return false;
        }
    }


    public void undoLastPath(){



        currentPaths.remove(currentPaths.size()-1);
    }
    public ArrayList<Uri> getAllCurrentPaths(){
        return  currentPaths;
    }
    public Uri getPathFromCurrentPathsById(int id){
        return currentPaths.get(id);
    }
    public String getNameById(int i){
        return namesOfExcercies.get(i);
    }
    public ArrayList<String> getAllNames(){
        return namesOfExcercies;
    }


    public void setNumberOfDays (int numberOfDays){
        this.numberOfDays  = numberOfDays;
    }
    public int getNumberOfDays(){
        return numberOfDays;
    }
    public void setCurrentDay(int i){
        currentDay = i;
    }

    public int getCurrentDay(){
        return currentDay;
    }
    public String getThisPath(){
        return thisPath;
    }
    public void setThisPath(String path){
        thisPath=path;
    }
    public int getAmountOfWorkoutToday(int day){
        return workoutList.get(day).size();
    }

    public ArrayList<HashMap<String,Uri>> getWorkoutPathList(){
        return workoutList;
    }
public void addDayInWorkoutList(){
    if (currentPaths.size() == currentNames.size()) {
        workoutList.add(new HashMap<String, Uri>() {

            {


                for (int i = 0; i < currentPaths.size(); i++) {


                    this.put(currentNames.get(i), currentPaths.get(i));
                }

            }

        });
        clearCustomNames();
        clearCurrentPaths();
    }else {
        Toast.makeText(context, "Ты шо крейзи?  Размер имен и путей не одинаков", Toast.LENGTH_LONG).show();
    }
    }



    public void clearWorkoutList(){
        if(workoutList==null){
            workoutList = new ArrayList<HashMap<String,Uri>>();
        }else{
        workoutList.clear();}
    }
    public ArrayList<ArrayList<WorkoutModel>> createListFromMap(ArrayList<HashMap<String,Uri>> map){

        ArrayList<ArrayList<WorkoutModel>> list = new ArrayList<ArrayList<WorkoutModel>>() ;
        for (int i = 0; i < map.size(); i++){
            ArrayList<WorkoutModel> listOfModels = new ArrayList<WorkoutModel> ();

        for (int j = 0; j < map.get(i).size(); j++){
            WorkoutModel model =  new WorkoutModel();
            model.setUri(map.get(i).values().toArray()[j].toString());
            model.setNameOfExc( map.get(i).keySet().toArray()[j].toString());
            listOfModels.add(model);

        }
            list.add(listOfModels);

        }


        return list;

    }
    public ArrayList<HashMap<String,Uri>> createHashMapList(ArrayList<ArrayList<WorkoutModel>> list){
        ArrayList<HashMap<String,Uri>> map = new ArrayList<HashMap<String,Uri>>();
        for (int i = 0; i < list.size(); i++){
            HashMap<String,Uri> hashMap = new HashMap<String,Uri>();

            for (int j = 0;j<list.get(i).size();j++){
                hashMap.put(list.get(i).get(j).getNameOfExc(),Uri.parse( list.get(i).get(j).getUri()));
            }
            map.add(hashMap);
        }


        return map;
    }
    public  void setWorkoutList(ArrayList<HashMap<String,Uri>> workoutList){
        this.workoutList = workoutList;
    }
    public void setIterator(int i){
        iterator = i;
    }


}
