package com.kursach.fitnessapp;

import android.net.Uri;

public class WorkoutModel {
    public String getUri() {
        return uri;
    }

    public void setUri(String uri) {
        this.uri = uri;
    }

    private String uri;

    public String getNameOfExc() {
        return nameOfExc;
    }

    public void setNameOfExc(String nameOfExc) {
        this.nameOfExc = nameOfExc;
    }

    private String nameOfExc;



}
