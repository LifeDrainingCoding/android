package com.kursach.fitnessapp;

import android.app.backup.RestoreObserver;
import android.content.Intent;
import android.content.SharedPreferences;
import android.media.browse.MediaBrowser;
import android.net.Uri;
import android.os.Handler;
import android.view.View;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import androidx.media3.common.MediaItem;
import androidx.media3.common.Player;
import androidx.media3.exoplayer.ExoPlayer;
import androidx.media3.ui.PlayerView;

import java.util.Timer;
import java.util.TimerTask;

public class BeginWorkoutActivity extends AppCompatActivity {
    ExoPlayer currentPlayer, nextPlayer;
    PlayerView currentPlayerView, nextPlayerView;
    TextView timeLeft, currentNameOfExc, nextNameOfExc;

     int prepareTime = 0;
     Timer prepareTimer = new Timer();
     Timer workoutTimer = new Timer();

     int currentDay;
     int workoutTime;
     int restTime;
     boolean isLast = false;
     int currentExc = 0;
     boolean isRest = false;
     int iterator = 0 ;
     Button nextExcBtn;
    ProgressBar progressBar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_begin_workout);
        timeLeft = findViewById(R.id.time_remain);
        currentNameOfExc = findViewById(R.id.currentNameOfExc);
        nextNameOfExc = findViewById(R.id.nextNameOfExc);
        nextPlayerView = findViewById(R.id.nextPlayerView);
        nextExcBtn = findViewById(R.id.nextExc);



        currentPlayerView = findViewById(R.id.currentPlayerView);





    }

    @Override
    protected void onStart() {
        super.onStart();
       progressBar = findViewById(R.id.progressBar);
       SharedPreferences prefs = getSharedPreferences("Workout", MODE_PRIVATE);

        workoutTime = prefs.getInt("WorkoutTime", 900);
        restTime = prefs.getInt("RestTime", 900);
        currentDay =  Singleton.getInstance(this).getCurrentDay();
        TimerTask workoutTask = new TimerTask() {
            @Override
            public void run() {
                Handler handler = new Handler(getMainLooper());
                Runnable runnable =  new Runnable() {
                    @Override
                    public void run() {
                        currentPlayer.play();
                        nextPlayer.play();

                        if(Singleton.getInstance(BeginWorkoutActivity.this).getWorkoutPathList().get(currentDay).keySet().toArray()[currentExc] == "Отдых")
                        {
                            isRest = true;
                            progressBar.setMax(restTime);
                            if(progressBar.getProgress() != restTime){
                                iterator= iterator+1;


                                progressBar.setProgress(iterator,true);
                                updateTimeTxt();
                            } else {
                                if (!isLast){
                                    progressBar.setProgress(0);
                                    iterator = 0;
                                    updateTimeTxt();
                                    currentExc++;
                                    currentNameOfExc.setText((String) Singleton.getInstance( BeginWorkoutActivity.this).getWorkoutPathList().get(currentDay).keySet().toArray()[currentExc]);
                                    nextNameOfExc.setText((String) Singleton.getInstance( BeginWorkoutActivity.this).getWorkoutPathList().get(currentDay).keySet().toArray()[currentExc+1]);

                                    if(currentPlayer.isPlaying()){
                                        try {
                                            currentNameOfExc.setText((String) Singleton.getInstance( BeginWorkoutActivity.this).getWorkoutPathList().get(currentDay).keySet().toArray()[currentExc]);
                                            nextNameOfExc.setText((String) Singleton.getInstance( BeginWorkoutActivity.this).getWorkoutPathList().get(currentDay).keySet().toArray()[currentExc+1]);
                                            currentPlayer.stop();
                                            nextPlayer.stop();
                                            currentPlayer.setMediaItem(MediaItem.fromUri((Uri) Singleton.getInstance(BeginWorkoutActivity.this).getWorkoutPathList().get(currentDay).values().toArray()[currentExc ]));
                                            nextPlayer.setMediaItem(MediaItem.fromUri((Uri) Singleton.getInstance(BeginWorkoutActivity.this).getWorkoutPathList().get(currentDay).values().toArray()[currentExc + 1]));
                                            nextPlayer.prepare();
                                            currentPlayer.prepare();
                                            currentPlayer.play();
                                            nextPlayer.play();
                                        } catch (IndexOutOfBoundsException ex) {
                                            isLast = true;
                                            nextPlayer.stop();
                                            nextPlayer.setMediaItem(MediaItem.EMPTY);
                                            nextNameOfExc.setText("");

                                        }}
                                }else {
                                    Toast.makeText(BeginWorkoutActivity.this, "Тренировка завершена!", Toast.LENGTH_LONG).show();
                                    workoutTimer.cancel();
                                    Intent intent =  new Intent(BeginWorkoutActivity.this, MainActivity.class);
                                    startActivity(intent);
                                    finish();
                                }
                            }

                        }else {
                            isRest = false;
                            progressBar.setMax(workoutTime);
                            if(progressBar.getProgress()!=workoutTime){
                                iterator= iterator +1;
                                progressBar.setProgress(iterator,true);
                                updateTimeTxt();

                            }else{
                                if (!isLast){
                                    progressBar.setProgress(0);
                                    iterator = 0;
                                    updateTimeTxt();

                                    currentExc++;


                                    if(currentPlayer.isPlaying()){
                                        try {
                                            currentNameOfExc.setText((String) Singleton.getInstance( BeginWorkoutActivity.this).getWorkoutPathList().get(currentDay).keySet().toArray()[currentExc]);
                                            nextNameOfExc.setText((String) Singleton.getInstance( BeginWorkoutActivity.this).getWorkoutPathList().get(currentDay).keySet().toArray()[currentExc+1]);
                                            currentPlayer.stop();
                                            nextPlayer.stop();
                                            currentPlayer.setMediaItem(MediaItem.fromUri((Uri) Singleton.getInstance(BeginWorkoutActivity.this).getWorkoutPathList().get(currentDay).values().toArray()[currentExc ]));
                                            nextPlayer.setMediaItem(MediaItem.fromUri((Uri) Singleton.getInstance(BeginWorkoutActivity.this).getWorkoutPathList().get(currentDay).values().toArray()[currentExc + 1]));
                                            nextPlayer.prepare();
                                            currentPlayer.prepare();
                                            currentPlayer.play();
                                            nextPlayer.play();
                                        } catch (IndexOutOfBoundsException ex) {
                                            currentPlayer.setMediaItem(MediaItem.fromUri((Uri) Singleton.getInstance(BeginWorkoutActivity.this).getWorkoutPathList().get(currentDay).values().toArray()[currentExc ]));
                                            currentPlayer.prepare();
                                            currentPlayer.play();
                                            isLast = true;
                                            nextPlayer.stop();
                                            nextPlayer.setMediaItem(MediaItem.EMPTY);
                                            nextNameOfExc.setText("");

                                        }}
                                }else {
                                    Toast.makeText(BeginWorkoutActivity.this, "Тренировка завершена!", Toast.LENGTH_LONG).show();
                                    Intent intent =  new Intent(BeginWorkoutActivity.this, MainActivity.class);
                                    workoutTimer.cancel();
                                    startActivity(intent);
                                    finish();
                                }

                            }
                        }
                    }



                };


                handler.post(runnable);


            }
        };

        TimerTask prepareTask = new TimerTask() {
            @Override
            public void run() {
                if (prepareTime == 0){
                    startPreparePlayers();
                    prepareTime++;

                }else if(prepareTime<5){
                    prepareTime++;
                }else{


                    prepareTime= 0;
                    prepareTimer.cancel();

                    workoutTimer.schedule(workoutTask,1000,1000);


                }
            }
        };

        prepareTimer.schedule(prepareTask,1000,1000);

        nextExcBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                currentExc++;
                iterator = 0;
                progressBar.setProgress(0);
                try {
                    currentNameOfExc.setText((String) Singleton.getInstance( BeginWorkoutActivity.this).getWorkoutPathList().get(currentDay).keySet().toArray()[currentExc]);
                    nextNameOfExc.setText((String) Singleton.getInstance( BeginWorkoutActivity.this).getWorkoutPathList().get(currentDay).keySet().toArray()[currentExc+1]);
                    currentPlayer.stop();
                    nextPlayer.stop();
                    currentPlayer.setMediaItem(MediaItem.fromUri((Uri) Singleton.getInstance(BeginWorkoutActivity.this).getWorkoutPathList().get(currentDay).values().toArray()[currentExc ]));
                    nextPlayer.setMediaItem(MediaItem.fromUri((Uri) Singleton.getInstance(BeginWorkoutActivity.this).getWorkoutPathList().get(currentDay).values().toArray()[currentExc + 1]));
                    nextPlayer.prepare();
                    currentPlayer.prepare();
                    currentPlayer.play();
                    nextPlayer.play();
                    updateTimeTxt();

                }catch (IndexOutOfBoundsException | NullPointerException ex){
                    currentPlayer.setMediaItem(MediaItem.fromUri((Uri) Singleton.getInstance(BeginWorkoutActivity.this).getWorkoutPathList().get(currentDay).values().toArray()[currentExc ]));
                    currentPlayer.prepare();
                    currentPlayer.play();
                    isLast = true;
                    nextPlayer.stop();

                    nextNameOfExc.setText("");
                    updateTimeTxt();
                    nextExcBtn.setEnabled(false);

                }
            }
        });

    }

    public  void updateTimeTxt(){
        if(isRest){

            currentNameOfExc.setText((String) Singleton.getInstance( BeginWorkoutActivity.this).getWorkoutPathList().get(currentDay).keySet().toArray()[currentExc]);
            nextNameOfExc.setText((String) Singleton.getInstance( BeginWorkoutActivity.this).getWorkoutPathList().get(currentDay).keySet().toArray()[currentExc+1]);

        timeLeft.setText( restTime -progressBar.getProgress());}else {
            timeLeft.setText(String.valueOf( workoutTime - progressBar.getProgress()));
        }

    }

    public void startPreparePlayers(){
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                currentPlayer = new ExoPlayer.Builder(BeginWorkoutActivity.this).build();
                nextPlayer =  new ExoPlayer.Builder(BeginWorkoutActivity.this).build();
                currentPlayer.setMediaItem( MediaItem.fromUri((Uri) Singleton.getInstance( BeginWorkoutActivity.this).getWorkoutPathList().get(currentDay).values().toArray()[currentExc]));
                nextPlayer.setMediaItem( MediaItem.fromUri((Uri) Singleton.getInstance( BeginWorkoutActivity.this).getWorkoutPathList().get(currentDay).values().toArray()[currentExc+1]));
                currentPlayerView.setPlayer(currentPlayer);
                nextPlayerView.setPlayer(nextPlayer);
                currentPlayerView.setUseController(false);
                nextPlayerView.setUseController(false);
                currentPlayer.setRepeatMode(Player.REPEAT_MODE_ALL);
                nextPlayer.setRepeatMode(Player.REPEAT_MODE_ALL);
                currentPlayer.prepare();
                nextPlayer.prepare();
                currentNameOfExc.setText((String) Singleton.getInstance( BeginWorkoutActivity.this).getWorkoutPathList().get(currentDay).keySet().toArray()[currentExc]);
nextNameOfExc.setText((String) Singleton.getInstance( BeginWorkoutActivity.this).getWorkoutPathList().get(currentDay).keySet().toArray()[currentExc+1]);
            }
        });
    }
}