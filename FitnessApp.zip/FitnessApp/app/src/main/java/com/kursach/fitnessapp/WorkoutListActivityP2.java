package com.kursach.fitnessapp;

import android.content.Intent;
import android.view.View;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import androidx.recyclerview.widget.RecyclerView;

public class WorkoutListActivityP2 extends AppCompatActivity {
    AdapterP1 adapterP2 = new AdapterP1(this);

    RecyclerView recyclerViewP2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_workout_list_p2);
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                recyclerViewP2 = findViewById(R.id.listP2);
                recyclerViewP2.setAdapter(adapterP2);
            }
        });
        

    }
    public void onFinish(View v){

        Singleton.getInstance(v.getContext()).addDayInWorkoutList();

        finish();
    }
    public void onClickBack(View v){
        Intent intent  = new Intent(this, WorkOutListActivity.class);
        startActivity(intent);
        finish();
    }


}