package com.kursach.fitnessapp;


import android.content.Context;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;
import androidx.media3.common.MediaItem;
import androidx.media3.common.MediaMetadata;
import androidx.media3.common.Player;
import androidx.media3.exoplayer.ExoPlayer;
import androidx.media3.ui.PlayerView;
import androidx.recyclerview.widget.RecyclerView;

public class AdapterP2 extends RecyclerView.Adapter<AdapterP2.ViewHolder> {

    Context context;
    public AdapterP2(Context context) {
        this.context = context;
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.fragment_dialog_item, parent, false);




        return new ViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(ViewHolder holder, int position) {

        holder.exoPlayer = new ExoPlayer.Builder(context).build();
        holder.exoPlayer.setMediaItem(MediaItem.fromUri(Singleton.getInstance(context).getPathP2ById(position)));
        holder.playerView.setPlayer(holder.exoPlayer);
        holder.playerView.setUseController(false);
        holder.exoPlayer.setRepeatMode(Player.REPEAT_MODE_ALL);
        holder.exoPlayer.prepare();
        holder.exoPlayer.play();

        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Singleton.getInstance(context).addNameToCustomNamesList(Singleton.getInstance(context).getNameByIdP2(holder.getAbsoluteAdapterPosition()));
                Singleton.getInstance(context).addPathToCurrentPaths(Singleton.getInstance(context).getPathP2ById(holder.getAbsoluteAdapterPosition()));
                Toast.makeText(context,"Добавлено!", Toast.LENGTH_SHORT).show();
            }
        });




        holder.textView.setText(Singleton.getInstance(context).getNameByIdP2(position));


    }

    @Override
    public int getItemCount() {

        return Singleton.getInstance(context).getAllPathsP2().size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        public PlayerView playerView;
        public ExoPlayer exoPlayer;

        public TextView textView;



        public ViewHolder(View view) {
            super(view);

            playerView= view.findViewById(R.id.player_view);

            textView = view.findViewById(R.id.content);


        }
    }

}