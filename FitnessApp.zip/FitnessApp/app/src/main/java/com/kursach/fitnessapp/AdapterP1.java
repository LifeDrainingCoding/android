package com.kursach.fitnessapp;


import android.content.Context;

import android.graphics.Bitmap;
import android.media.MediaMetadataRetriever;
import android.net.Uri;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.annotation.OptIn;
import androidx.media3.common.MediaItem;
import androidx.media3.common.MediaMetadata;
import androidx.media3.common.Player;
import androidx.media3.common.util.UnstableApi;
import androidx.media3.exoplayer.ExoPlayer;
import androidx.media3.exoplayer.SimpleExoPlayer;
import androidx.media3.ui.PlayerView;
import androidx.recyclerview.widget.RecyclerView;
import org.jetbrains.annotations.NotNull;

public class AdapterP1 extends RecyclerView.Adapter<AdapterP1.ViewHolder> {

Context context;
    public AdapterP1(Context context) {
this.context = context;
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.fragment_dialog_item, parent, false);




        return new ViewHolder(itemView);
    }

    @OptIn(markerClass = UnstableApi.class) @Override
    public void onBindViewHolder(ViewHolder holder, int position) {



        MediaMetadataRetriever retriever = new MediaMetadataRetriever();
        retriever.setDataSource(context, Singleton.getInstance(context).getAllPaths().get(position));
        Bitmap bitmap = retriever.getFrameAtTime(-1);
        holder.imageView.setImageBitmap(bitmap);

            holder.itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Singleton.getInstance(context).addNameToCustomNamesList(Singleton.getInstance(context).getNameById(holder.getAbsoluteAdapterPosition()));
                    Singleton.getInstance(context).addPathToCurrentPaths(Singleton.getInstance(context).getPathById(holder.getAbsoluteAdapterPosition()));
                    Toast.makeText(context,"Добавлено!", Toast.LENGTH_SHORT).show();
                }
            });















        holder.textView.setText(Singleton.getInstance(context).getNameById(position));


    }

    @Override
    public int getItemCount() {

        return Singleton.getInstance(context).getAllPaths().size();
    }

    @Override
    public void onViewAttachedToWindow(@NonNull @NotNull ViewHolder holder) {
        super.onViewAttachedToWindow(holder);

    }

    @Override
    public void onViewDetachedFromWindow(@NonNull @NotNull ViewHolder holder) {
        super.onViewDetachedFromWindow(holder);


    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        public ImageView imageView;


        public TextView textView;



        public ViewHolder(View view) {
            super(view);


           imageView= view.findViewById(R.id.imagePreview);

            textView = view.findViewById(R.id.content);


        }

    }


}
