package com.kursach.fitnessapp;



import android.content.Context;
import android.graphics.Bitmap;
import android.media.MediaMetadataRetriever;
import android.net.Uri;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.recyclerview.widget.RecyclerView;

public class AdapterToTodaysWorkout extends RecyclerView.Adapter<AdapterToTodaysWorkout.ViewHolder> {
Context context;

    public AdapterToTodaysWorkout(Context context) {
this.context = context;
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.todays_item, parent, false);
        Singleton.getInstance(itemView.getContext());

        return new ViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(ViewHolder holder, int position) {


            MediaMetadataRetriever retriever = new MediaMetadataRetriever();
            retriever.setDataSource(context, (Uri) Singleton.getInstance(context).getWorkoutPathList().get(Singleton.getInstance(context).getCurrentDay()).values().toArray()[position]);
        Bitmap bitmap = retriever.getFrameAtTime(-1);
        holder.imageView.setImageBitmap(bitmap);
        holder.textView.setText(Singleton.getInstance(context).getWorkoutPathList().get(Singleton.getInstance(context).getCurrentDay()).keySet().toArray()[position].toString());
    }

    @Override
    public int getItemCount() {
        return Singleton.getInstance(context).getWorkoutPathList().get(Singleton.getInstance(context).getCurrentDay()).size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        public ImageView imageView;
        public TextView textView;

        public ViewHolder(View view) {
            super(view);
            imageView = view.findViewById(R.id.imageView);
            textView = view.findViewById(R.id.content);
        }
    }

}

