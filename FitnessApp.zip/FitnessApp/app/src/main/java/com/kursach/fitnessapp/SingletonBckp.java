package com.kursach.fitnessapp;


import android.content.Context;
import android.net.Uri;





import java.util.ArrayList;

public class SingletonBckp {
    static Context context;




    private static Singleton instance;
    private ArrayList<String> days;
    private ArrayList<Uri> currentPaths = new ArrayList<>();
    private ArrayList<String> customNames = new ArrayList<>();
    private int numberOfDays;
    private int currentDay;
    private String thisPath;

    static Uri[] uri;
    private ArrayList<ArrayList<Uri>> workoutList = new ArrayList<>();
    private ArrayList<String> namesOfExcercies = new ArrayList<String>(){
        {
            add("Сведение лопаток");
            add("Сведение лопаток гантелями");
            add("Растягивание голени");
            add("Сведение рук с гантелями");
            add("Отдых");
            add("Походите/Погуляйте");
            add("Лифтинг гантелей");
            add("Выпады");
            add("Подтягивание на турнике");
            add("Подтягивание гантелей");
            add("Подтягивание из бока в бок");
            add("Подтягивание полу-лежа");
            add("Подтягивание сидя");
            add("Жим гантелей лежа");
            add("Жим гантелей");
            add("Развод рук в стороны");
            add("Присяды с гантелями");
            add("Спортивный танец");
            add("Спортивные прыжки");
            add("Спортивные пинки");
            add("Шаги вверх с гантелями");
            add("Ходьба с гантелями");
        }
    };
    private static ArrayList<Uri> allPaths ;


    public static Singleton getInstance(Context context1) {
        context = context1;
        if(context!=null){
            if (instance == null) {
                instance = new Singleton();
            }

            uri = new Uri[]{
                    Uri.parse("android.resource://" + context.getPackageName() + "/" + R.raw.adjusting_the_blades),
                    Uri.parse("android.resource://" + context.getPackageName() + "/" + R.raw.adjusting_the_blades_by_lifting_dumbells),
                    Uri.parse("android.resource://" + context.getPackageName() + "/" + R.raw.calf_stretching),
                    Uri.parse("android.resource://" + context.getPackageName() + "/" + R.raw.hand_reduction_with_dumbells),
                    Uri.parse("android.resource://" + context.getPackageName() + "/" + R.raw.just_chillin),
                    Uri.parse("android.resource://" + context.getPackageName() + "/" + R.raw.just_hanging_around),
                    Uri.parse("android.resource://" + context.getPackageName() + "/" + R.raw.lifting),
                    Uri.parse("android.resource://" + context.getPackageName() + "/" + R.raw.lunges),
                    Uri.parse("android.resource://" + context.getPackageName() + "/" + R.raw.pull_ups),
                    Uri.parse("android.resource://" + context.getPackageName() + "/" + R.raw.pull_ups_dumbells),
                    Uri.parse("android.resource://" + context.getPackageName() + "/" + R.raw.pull_ups_side_by_side),
                    Uri.parse("android.resource://" + context.getPackageName() + "/" + R.raw.pull_ups_while_half_laying),
                    Uri.parse("android.resource://" + context.getPackageName() + "/" + R.raw.pull_ups_while_sitting),
                    Uri.parse("android.resource://" + context.getPackageName() + "/" + R.raw.push_ups_laying_with_dumbells),
                    Uri.parse("android.resource://" + context.getPackageName() + "/" + R.raw.push_ups_with_dumbells),
                    Uri.parse("android.resource://" + context.getPackageName() + "/" + R.raw.raising_hands),
                    Uri.parse("android.resource://" + context.getPackageName() + "/" + R.raw.sit_downs_with_dumbells),
                    Uri.parse("android.resource://" + context.getPackageName() + "/" + R.raw.sport_dance),
                    Uri.parse("android.resource://" + context.getPackageName() + "/" + R.raw.sport_jumps),
                    Uri.parse("android.resource://" + context.getPackageName() + "/" + R.raw.sport_kicks),
                    Uri.parse("android.resource://" + context.getPackageName() + "/" + R.raw.step_ups_with_dumbells),
                    Uri.parse("android.resource://" + context.getPackageName() + "/" + R.raw.walking_with_dumbells)

            };
            allPaths = new ArrayList<Uri>(){
                {

                    for (int i=0; i<21;i++){
                        add(uri[i]);
                    }





                }
            };
            return instance;}else {
            throw new NullPointerException("Синглтону не задан контекст в:"+ Singleton.class.getSimpleName());
        }
    }


    public Uri getPathById(int i){
        return allPaths.get(i);
    }
    public ArrayList<Uri> getAllPaths(){
        return allPaths;
    }
    public void addNameToCustomNamesList(String name){
        customNames.add(name);
    }
    public void clearCustomNames(){
        customNames = new ArrayList<>();
    }
    public String getCustomNameById(int id){
        return customNames.get(id);
    }
    public void undoLastCustomName(){
        customNames.remove(customNames.size()-1);
    }
    public void  addPathToCurrentPaths( String uri){
        currentPaths.add(Uri.parse(uri));
    }
    public String getCurrentPathById(int id){
        return   currentPaths.get(id).getPath();
    }
    public void clearCurrentPaths(){
        currentPaths = new ArrayList<Uri>();
    }
    public void undoLastPath(){



        currentPaths.remove(currentPaths.size()-1);
    }
    public ArrayList<Uri> getAllCurrentPaths(){
        return  currentPaths;
    }
    public Uri getPathFromCurrentPathsById(int id){
        return currentPaths.get(id);
    }
    public String getNameById(int i){
        return namesOfExcercies.get(i);
    }
    public ArrayList<String> getAllNames(){
        return namesOfExcercies;
    }
    public void addDay(int day){
        days.add("День"+day);
    }
    public String getDay(int day){
        return days.get(day);
    }
    public void clearDays(){
        days.clear();
    }
    public void setNumberOfDays (int numberOfDays){
        this.numberOfDays  = numberOfDays;
    }
    public int getNumberOfDays(){
        return numberOfDays;
    }
    public void setCurrentDay(int i){
        currentDay = i;
    }

    public int getCurrentDay(){
        return currentDay;
    }
    public String getThisPath(){
        return thisPath;
    }
    public void setThisPath(String path){
        thisPath=path;
    }

    public ArrayList<ArrayList<Uri>> getWorkoutList(){
        return workoutList;
    }
    public void addDayInWorkoutList(){
        workoutList.add(currentPaths);
        clearCurrentPaths();
    }

    public void clearWorkoutList(){
        workoutList.clear();
    }

}
