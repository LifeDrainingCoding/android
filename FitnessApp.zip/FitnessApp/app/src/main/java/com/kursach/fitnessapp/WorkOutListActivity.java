package com.kursach.fitnessapp;

import android.content.Intent;
import android.view.View;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import androidx.media3.common.MediaItem;
import androidx.media3.exoplayer.ExoPlayer;
import androidx.media3.ui.PlayerView;
import androidx.recyclerview.widget.RecyclerView;

public class WorkOutListActivity extends AppCompatActivity {

    AdapterP1 adapterP1 = new AdapterP1(this);

    RecyclerView recyclerViewP1;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_work_out_list);





            recyclerViewP1 = findViewById(R.id.listP1);
            recyclerViewP1.setAdapter(adapterP1);


    }
    public void onFinish1(View v){

        Singleton.getInstance(v.getContext()).addDayInWorkoutList();

        finish();

    }
    public void  onClick(View v){
        Intent intent = new Intent(this, WorkoutListActivityP2.class);
        startActivity(intent);
        finish();
    }

    @Override
    protected void onResume() {
        super.onResume();


                recyclerViewP1 = findViewById(R.id.listP1);
                recyclerViewP1.setAdapter(adapterP1);

    }
}