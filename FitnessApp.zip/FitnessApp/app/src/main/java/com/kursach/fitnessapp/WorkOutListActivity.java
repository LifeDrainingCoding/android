package com.kursach.fitnessapp;

import android.content.Intent;
import android.view.View;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import androidx.recyclerview.widget.RecyclerView;

public class WorkOutListActivity extends AppCompatActivity {

    AdapterP1 adapterP1 = new AdapterP1(this);

    RecyclerView recyclerViewP1;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_work_out_list);




    runOnUiThread(new Runnable() {
        @Override
        public void run() {
            recyclerViewP1 = findViewById(R.id.listP2);
            recyclerViewP1.setAdapter(adapterP1);
        }
    });


    }
    public void onFinish(View v){

        Singleton.getInstance(v.getContext()).addDayInWorkoutList();

        finish();

    }
    public void  onClick(View v){
        Intent intent = new Intent(this, WorkoutListActivityP2.class);
        startActivity(intent);
        finish();
    }


}