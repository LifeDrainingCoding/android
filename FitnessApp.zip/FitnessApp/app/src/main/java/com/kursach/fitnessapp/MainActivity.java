package com.kursach.fitnessapp;

import android.content.Intent;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import androidx.recyclerview.widget.RecyclerView;

public class MainActivity extends AppCompatActivity {
    RecyclerView recyclerView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Button configurePlan =  findViewById(R.id.configurePlane);
        recyclerView =  findViewById(R.id.dayslist1);
        try {








        AdapterToDays adapter =  new AdapterToDays(MainActivity.this);
        recyclerView.setAdapter(adapter);


} catch (Exception ex){
            Toast.makeText(this, "Определите сперва план тренировок!", Toast.LENGTH_SHORT).show();
        }
        configurePlan.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent =  new Intent(v.getContext(), ConfigureWorkoutActivity.class);
                Singleton.getInstance(v.getContext()).clearWorkoutList();
                startActivity(intent);

            }
        });


    }

    @Override
    protected void onStart() {
        super.onStart();





       
    }

    @Override
    protected void onResume() {
        super.onResume();
        runOnUiThread(new Runnable() {
            @Override
            public void run() {

                AdapterToDays adapter =  new AdapterToDays(MainActivity.this);
                recyclerView.setAdapter(adapter);

            }
        });
    }
}