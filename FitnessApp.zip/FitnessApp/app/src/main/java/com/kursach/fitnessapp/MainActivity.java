package com.kursach.fitnessapp;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Environment;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import androidx.recyclerview.widget.RecyclerView;
import com.google.common.reflect.TypeToken;
import com.google.gson.Gson;

import java.io.*;
import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.HashMap;

import static com.kursach.fitnessapp.Singleton.context;

public class MainActivity extends AppCompatActivity {

    RecyclerView recyclerView;
    ArrayList<ArrayList<WorkoutModel>> workoutList;
    TextView textView;
    private static final int PERMISSION_STORAGE = 100;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Button configurePlan =  findViewById(R.id.configurePlane);
        recyclerView =  findViewById(R.id.dayslist1);




        loadRecView();
        configurePlan.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent =  new Intent(v.getContext(), ConfigureWorkoutActivity.class);

                SharedPreferences sharedPreferences = getSharedPreferences("Workout", MODE_PRIVATE);
                SharedPreferences.Editor editor = sharedPreferences.edit();
                editor.putString("WorkoutPathList", null);

                Singleton.getInstance(v.getContext()).setNumOfDays(-1);
                Singleton.getInstance(v.getContext()).setCurrentDay(-1);
                editor.apply();

                startActivity(intent);

            }
        });


    }

    @Override
    protected void onStart() {
        super.onStart();




       
    }

    @Override
    protected void onResume() {
        super.onResume();
     loadRecView();



    }
    public void loadRecView(){
                try {
                       SharedPreferences sharedPreferences = getSharedPreferences("Workout", MODE_PRIVATE);
                        Gson gson = new Gson();
                        String json = sharedPreferences.getString("WorkoutPathList", null);
                    workoutList = gson.fromJson(json, new TypeToken<ArrayList<ArrayList<WorkoutModel>>>() {
                    }.getType());
                    Singleton.getInstance(this).setWorkoutList(Singleton.getInstance(this).createHashMapList(workoutList));

                recyclerView.setAdapter(new AdapterToDays(MainActivity.this, workoutList));

                }
                catch (ClassCastException | NullPointerException ex){
                    Toast.makeText(MainActivity.this, "Определите план тренировок!", Toast.LENGTH_SHORT).show();
                }
    }
    public void clearAndRestart(View v) {
        try {

            Process process = Runtime.getRuntime().exec("pm clear com.kursach.fitnessapp");
            process.waitFor();
            Intent mStartActivity = new Intent(this, MainActivity.class);
            int mPendingIntentId = 123456;
            PendingIntent mPendingIntent = PendingIntent.getActivity(this, mPendingIntentId,    mStartActivity, PendingIntent.FLAG_CANCEL_CURRENT | PendingIntent.FLAG_IMMUTABLE);
            AlarmManager mgr = (AlarmManager)this.getSystemService(Context.ALARM_SERVICE);
            mgr.set(AlarmManager.RTC, System.currentTimeMillis() + 1000, mPendingIntent);



        }catch (IOException| InterruptedException ex){

        }
    }



}