package com.kursach.fitnessapp;



import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Bitmap;
import android.media.MediaMetadataRetriever;
import android.net.Uri;
import android.os.Build;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.recyclerview.widget.RecyclerView;

public class AdapterToDays extends RecyclerView.Adapter<AdapterToDays.ViewHolder> {
    Context context;

    public AdapterToDays(Context context) {
        this.context = context;
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.days_list_item, parent, false);

        return new ViewHolder(itemView);
    }

    @SuppressLint("SetTextI18n")
    @Override
    public void onBindViewHolder(ViewHolder holder, int position) {
        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(holder.checkBox.isChecked()){
                    AlertDialog builder = new AlertDialog.Builder(context)
                            .setTitle("Вы уверены что хотите перепройти день "+holder.getBindingAdapterPosition()+"?")
                            .setPositiveButton("Да", new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialog, int which) {
                                    holder.checkBox.setChecked(false);
                                    Intent intent = new Intent(context, TodaysWorkoutActivity.class);
                                    Singleton.getInstance(context).setCurrentDay(holder.getAbsoluteAdapterPosition());
                                    dialog.cancel();
                                    context.startActivity(intent);
                                }
                            }).setNegativeButton("Нет", new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialog, int which) {
                                    dialog.cancel();
                                }
                            }).create();
                    builder.show();
                }else{
                    Intent intent = new Intent(context, TodaysWorkoutActivity.class);
                    Singleton.getInstance(context).setCurrentDay(holder.getAbsoluteAdapterPosition());
                    holder.checkBox.setChecked(true);
                    context.startActivity(intent);
                }
            }
        });
        holder.textView.setText("День "+position+":: "+Singleton.getInstance(context).getWorkoutPathList().get(position).size()+" Упражнений");
    }

    @Override
    public int getItemCount() {
        return Singleton.getInstance(context).getWorkoutPathList().size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        public CheckBox checkBox;
        public TextView textView;

        public ViewHolder(View view) {
            super(view);
            checkBox =  view.findViewById(R.id.checkBox);
            checkBox.setClickable(false);
            textView = view.findViewById(R.id.dayTxt);
        }
    }

}

