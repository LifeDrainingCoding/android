package com.kursach.fitnessapp;



import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.media.MediaMetadataRetriever;
import android.net.Uri;
import android.os.Build;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import androidx.recyclerview.widget.RecyclerView;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.util.ArrayList;
import java.util.HashMap;

public class AdapterToDays extends RecyclerView.Adapter<AdapterToDays.ViewHolder> {

    Context context;
    ArrayList<ArrayList<WorkoutModel>> arrayList;
    ArrayList<Boolean> isChecked;



    public AdapterToDays(Context context, ArrayList<ArrayList<WorkoutModel>> arrayList) {
        this.context = context;
        this.arrayList = arrayList;


    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.days_list_item, parent, false);



            SharedPreferences preferences = context.getSharedPreferences("Workout", Context.MODE_PRIVATE);



        try {


            isChecked = new Gson().fromJson(new String(preferences.getString("isChecked", null)), new TypeToken<ArrayList<Boolean>>() {
            }.getType());
                }catch (NullPointerException ex) {
            System.out.println("Нулл блять");
            isChecked = new ArrayList<Boolean>();
            for (int i = 0; i <= arrayList.size(); i++) {
                isChecked.add(false);
    }
}





        return new ViewHolder(itemView);
    }

    @SuppressLint("SetTextI18n")
    @Override
    public void onBindViewHolder(ViewHolder holder, int position) {

holder.checkBox.setChecked(isChecked.get(position));




        try {

            holder.itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    SharedPreferences preferences = context.getSharedPreferences("Workout",Context.MODE_PRIVATE );
                    SharedPreferences.Editor  editor= preferences.edit();
                    if (holder.checkBox.isChecked()) {
                        AlertDialog builder = new AlertDialog.Builder(context)
                                .setTitle("Вы уверены что хотите перепройти день " + holder.getBindingAdapterPosition() + "?")
                                .setPositiveButton("Да", new DialogInterface.OnClickListener() {
                                    @Override
                                    public void onClick(DialogInterface dialog, int which) {

                                        Intent intent = new Intent(context, TodaysWorkoutActivity.class);
                                        Singleton.getInstance(context).setCurrentDay(holder.getAbsoluteAdapterPosition());
                                        isChecked.set(holder.getAbsoluteAdapterPosition(),true);
                                        editor.putString("isChecked", new String(new Gson().toJson(isChecked)));
                                        editor.apply();
                                        dialog.cancel();
                                        context.startActivity(intent);
                                    }
                                }).setNegativeButton("Нет", new DialogInterface.OnClickListener() {
                                    @Override
                                    public void onClick(DialogInterface dialog, int which) {
                                        dialog.cancel();
                                    }
                                }).create();
                        builder.show();
                    } else {
                        Intent intent = new Intent(context, TodaysWorkoutActivity.class);
                        Singleton.getInstance(context).setCurrentDay(holder.getAbsoluteAdapterPosition());

                        holder.checkBox.setChecked(true);
                        isChecked.set(holder.getAbsoluteAdapterPosition(),true);
                        editor.putString("isChecked", new Gson().toJson(isChecked));
                        editor.apply();
                        context.startActivity(intent);
                    }
                }
            });
            holder.textView.setText("День " + position + ":: " + arrayList.get(position).size()+ " Упражнений");
        }catch (NullPointerException ex){

        }
    }

    @Override
    public int getItemCount() {
        try {


        return arrayList.size();}
        catch (NullPointerException ex){
            Toast.makeText(context, "Определите план тренировок!", Toast.LENGTH_SHORT).show();
            return 0;
        }
    }



    public static class ViewHolder extends RecyclerView.ViewHolder {
        public CheckBox checkBox;
        public TextView textView;

        public ViewHolder(View view) {
            super(view);
            checkBox =  view.findViewById(R.id.checkBox);
            checkBox.setClickable(false);
            textView = view.findViewById(R.id.dayTxt);

        }
    }

}

