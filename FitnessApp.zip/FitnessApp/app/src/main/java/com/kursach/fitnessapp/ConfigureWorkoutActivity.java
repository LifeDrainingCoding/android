package com.kursach.fitnessapp;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Environment;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import com.google.gson.Gson;

import java.io.File;
import java.io.FileOutputStream;
import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.List;

public class ConfigureWorkoutActivity extends AppCompatActivity {
    Button beginConfigurationBtn, endPlanConfiguration;
EditText numberOfDays, amountTimeOfRestTxt, amountTimeToCompleteTxt;
int numOfDays;
@Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_configure_workout);
        numberOfDays =findViewById(R.id.num_of_daysTxt);
        amountTimeOfRestTxt = findViewById(R.id.rest_valueTxt);
        amountTimeToCompleteTxt = findViewById(R.id.time_to_deal_with_ex);
        beginConfigurationBtn =  findViewById(R.id.beginPlanConf);
        endPlanConfiguration =  findViewById(R.id.finishPlan);






    }

    @Override
    protected void onStart() {
        super.onStart();
        endPlanConfiguration.setEnabled(false);

        beginConfigurationBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {



                numOfDays = Integer.parseInt(numberOfDays.getText().toString());
                if (numOfDays >= 1) {
                    Singleton.getInstance(v.getContext()).setNumOfDays(numOfDays);

                    SharedPreferences  prefs = getSharedPreferences("Workout", MODE_PRIVATE);
                    SharedPreferences.Editor editor = prefs.edit();
                    editor.putInt("RestTime",Integer.parseInt(amountTimeOfRestTxt.getText().toString()));
                    editor.putInt("WorkoutTime",Integer.parseInt(amountTimeToCompleteTxt.getText().toString()) );

                    editor.apply();
                    repeater();

                } else {
                    Toast.makeText(v.getContext(), "Я смотрю ты гений и решил систему наэтовать", Toast.LENGTH_LONG).show();
                }

            }
        });

        endPlanConfiguration.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(v.getContext(), MainActivity.class);
                ArrayList<ArrayList<WorkoutModel>> workout = Singleton.getInstance(v.getContext()).createListFromMap(Singleton.getInstance(v.getContext()).getWorkoutPathList());
                Gson gson = new Gson();
Singleton.getInstance(v.getContext()).setIterator(0);
                String arraylist =  gson.toJson(workout);
               SharedPreferences  prefs = getSharedPreferences("Workout", MODE_PRIVATE);
                SharedPreferences.Editor editor = prefs.edit();
                editor.remove("WorkoutPathList");
                editor.putString("WorkoutPathList", arraylist);
                editor.apply();
                startActivity(intent);
                finish();

            }
        });

    }

    @Override
    protected void onStop() {
        super.onStop();


    }



    @Override
    protected void onResume() {
        super.onResume();

            repeater();


    }

    public void repeater(){
        try {
            if(Singleton.getInstance(this).getIterator()== Singleton.getInstance(this).getNumOfDays() || Singleton.getInstance(this).getIterator()>=Singleton.getInstance(this).getNumOfDays()){
                Singleton.getInstance(this).setFinishedConf(true);
            }else {
                Singleton.getInstance(this).incIterator();
                Singleton.getInstance(this).setFinishedConf(false);
            }

          if (Singleton.getInstance(this).isFinishedConf() == false) {


              Intent intent = new Intent(this, WorkOutListActivity.class);
              endPlanConfiguration.setEnabled(false);
              startActivity(intent);

          }else{
            endPlanConfiguration.setEnabled(true);}
        }catch (Exception ignored){

        }
    }
}