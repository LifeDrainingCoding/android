package com.example.Quize;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;

import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;


public class MainActivity extends AppCompatActivity {
    private TextView questionTextView;
    private Button noButton;
    private Button yesButton;
    private Button next,prev;

    private String[] questions;
    private int currentQuestionIndex;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        questionTextView = findViewById(R.id.questionTextView);
        noButton = findViewById(R.id.noButton);
        yesButton = findViewById(R.id.yesButton);
        next = findViewById(R.id.next);
        prev = findViewById(R.id.prev);

        questions = new String[]{"Земля крутится вокруг Солнца?", "Луна крутится вокруг Земли?", "Андромеда спутник Плутона?", "Ио Спутник Сатурна?"};
        currentQuestionIndex = 0;


        questionTextView.setText(questions[currentQuestionIndex]);
        prev.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                setPrev();
            }
        });
        next.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                setNext();
            }
        });

        noButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                checkAnswer(false);
            }
        });

        yesButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                checkAnswer(true);
            }
        });
    }
    private void setPrev(){
        if (currentQuestionIndex > 0){
            currentQuestionIndex--;
            questionTextView.setText(questions[currentQuestionIndex]);
        } else {
            Toast.makeText(this, "Дальше нет пути", Toast.LENGTH_SHORT).show();
        }
    }
    private void setNext (){
        if (currentQuestionIndex < 4){
            currentQuestionIndex++;
            questionTextView.setText(questions[currentQuestionIndex]);

        } else {
            Toast.makeText(this, "Дальше нет пути", Toast.LENGTH_SHORT).show();
        }
    }
    private void checkAnswer(boolean userAnswer) {
        String currentQuestion = questions[currentQuestionIndex];
        boolean correctAnswer = isAnswerCorrect(currentQuestion);

        if (userAnswer == correctAnswer) {
            Toast.makeText(this, "Правильно!", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(this, "Ложь", Toast.LENGTH_SHORT).show();
        }


        currentQuestionIndex++;
        if (currentQuestionIndex < questions.length) {
            questionTextView.setText(questions[currentQuestionIndex]);
        } else {

            questionTextView.setText("Quiz completed!");
            noButton.setEnabled(false);
            yesButton.setEnabled(false);
        }
    }
    private boolean isAnswerCorrect(String question) {
        if(question.equals("Земля крутится вокруг Солнца?")) {
           return true;
        }
        if (question.equals("Луна крутится вокруг Земли?")){
            return true;
        }
        if (question.equals("Ганимед спутник Плутона?")){
            return false;
        }
        if (question.equals("Ио Спутник Сатурна?")){
            return false;
        }
        return false;
    }
}
