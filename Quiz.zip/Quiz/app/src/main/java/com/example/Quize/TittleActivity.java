package com.example.Quize;

import android.content.Intent;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;

public class TittleActivity extends AppCompatActivity {
    private Button next_activity;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tittle);
        next_activity = findViewById(R.id.nextActivity);
        TextView welcome = findViewById(R.id.welcome);
        Intent intent = new Intent(this,MainActivity.class);

        next_activity.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(intent);
            }
        });

    }
}