package com.example.taxi;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;



public class MainActivity extends AppCompatActivity {
    SharedPreferences sharedPref;
    SharedPreferences.Editor editor;

private Button next;
private EditText surname,name ,phone ;
String surname1,name1,phone1;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        sharedPref = getPreferences(Context.MODE_PRIVATE);
        editor = sharedPref.edit();
                surname = findViewById(R.id.surname);
        name = findViewById(R.id.name);
        phone = findViewById(R.id.phone);
        next = findViewById(R.id.next);

        next.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                sendExtra();
            }
        });


    }

    @Override
    protected void onStop() {
        super.onStop();
        surname1 = surname.getText().toString();
        name1 = name.getText().toString();
        phone1 = phone.getText().toString();
        editor.putString(name1, "" );
        editor.putString(surname1, "" );
        editor.putString(phone1,"" );
        editor.apply();
        editor.commit();
    }

    @Override
    protected void onStart() {
        super.onStart();
        if (sharedPref.contains(name1) & sharedPref.contains(surname1) & sharedPref.contains(phone1)){
            surname.setText(sharedPref.getString(surname1,""));
            name.setText(sharedPref.getString(name1,""));
            phone.setText(sharedPref.getString(phone1,""));
        }
        if(name1 != null){
            next.setText("Войти");
        }
    }

    public void sendExtra(){
        if (name.getText().toString() != null & surname.getText().toString() != null){
            Intent intent =  new Intent(this, OperateActivity.class);
            intent.putExtra("name", name.getText().toString());
            intent.putExtra("surname", surname.getText().toString());
            intent.putExtra("phone", phone.getText().toString());
            startActivity(intent);


        }else {
            Toast.makeText(MainActivity.this,"Введите данные", Toast.LENGTH_SHORT);
        }
    }
}