package com.example.taxi;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;

import java.util.Timer;
import java.util.TimerTask;

public class OperateActivity extends AppCompatActivity {

    int index = 0;

    private TextView nameView ,phoneView,pathView;
private String surname,name,phone;
private String d1,d2,d3,d4,d5,d6,d7;
private Button setPath, callTaxi;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
         super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_operate);
        Intent intent = new Intent(this,PathConfigActivity.class);
        System.out.println("alive");
        setPath = findViewById(R.id.setPath);
        callTaxi = findViewById(R.id.callTaxi);
        setPath.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(intent);
            }
        });
        callTaxi.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(OperateActivity.this,"Такси вызванно!",Toast.LENGTH_SHORT).show();
            }
        });



    }

    @Override
    protected void onStart() {
        super.onStart();
        System.out.println("started");

        Intent intent1 = getIntent();
         d1 = intent1.getStringExtra("1");
         d2 = intent1.getStringExtra("2");
         d3 = intent1.getStringExtra("3");
         d4 = intent1.getStringExtra("1");
         d5 = intent1.getStringExtra("1");
         d6 = intent1.getStringExtra("1");
         d7 = intent1.getStringExtra("7");
        phoneView = findViewById(R.id.phoneView);
        pathView = findViewById(R.id.pathView);
        nameView = findViewById(R.id.nameView);
        if(index != 1){
        surname = intent1.getStringExtra("surname");
        name = intent1.getStringExtra("name");
        phone = intent1.getStringExtra("phone");
        nameView.setText(surname+ " "+name);
        phoneView.setText(phone);
        index = 1;
        }
        SharedPreferences sharedPref = getSharedPreferences("pref", MODE_PRIVATE);
        String savedValue = sharedPref.getString("saveValue","");
        String savedValue1 = sharedPref.getString("saveValue1","");
        if (phoneView ==  null){
            if (savedValue1 != null) {
                nameView.setText(savedValue);
                phoneView.setText(savedValue1);
            }

        }


        if(d1 != null){
            if(d2 != null){
                if(d3 != null){
                    if(d4 != null){
                        if(d5 != null){
                            if(d6 != null){
                                if(d7 != null){

                                    pathView.setText(d1+","+d2+","+d3+","+d4+","+d5+","+d6+","+d7);
                                }
                            }
                        }
                    }
                }
            }
        }
        check_path();

    }

    @Override
    protected void onResume() {
        super.onResume();


        System.out.println("resumed");

        //if(sharedPref.contains(name1)){
         //   nameView.setText(sharedPref.getString(name1,""));
           // phoneView.setText(sharedPref.getString(phone1,""));}
    }

    @Override
    protected void onStop() {
        super.onStop();
        System.out.println("stoped");
        nameView = findViewById(R.id.nameView);
        phoneView =findViewById(R.id.phoneView);
        SharedPreferences sharedPref = getSharedPreferences("prefs", MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPref.edit();
        String saveValue = surname + ""+ name;
        String saveValue1 = phone;
        editor.putString("saveValue",saveValue);
        editor.putString("saveValue1",saveValue1);
        editor.apply();
        }



    @Override
    protected void onPause() {
        super.onPause();
        System.out.println("paused");

    }

    private void check_path() {
       if (!pathView.getText().equals("Нет маршрута")) {
           callTaxi.setEnabled(true);
       }else {
           callTaxi.setEnabled(false);
       }
   }
}