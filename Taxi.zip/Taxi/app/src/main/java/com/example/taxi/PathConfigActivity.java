package com.example.taxi;

import android.content.Intent;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.activity.OnBackPressedCallback;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;

public class PathConfigActivity extends AppCompatActivity {
        Intent intent;

    private EditText editTextTextPersonName1, editTextTextPersonName2, editTextTextPersonName3, editTextTextPersonName4, editTextTextPersonName5, editTextTextPersonName6, editTextTextPersonName7;
    private Button sendData;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_path_config);
        editTextTextPersonName1 = findViewById(R.id.editTextTextPersonName1);
        editTextTextPersonName2 = findViewById(R.id.editTextTextPersonName2);
        editTextTextPersonName3 = findViewById(R.id.editTextTextPersonName3);
        editTextTextPersonName4= findViewById(R.id.editTextTextPersonName4);
        editTextTextPersonName5 = findViewById(R.id.editTextTextPersonName5);
        editTextTextPersonName6= findViewById(R.id.editTextTextPersonName6);
        editTextTextPersonName7 = findViewById(R.id.editTextTextPersonName7);
        sendData = findViewById(R.id.button);
        sendData.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                sendData();
                getOnBackPressedDispatcher();

            }
        });

    }
    public void sendData(){
        intent = new Intent(this, OperateActivity.class);
          if (editTextTextPersonName1.getText() != null){
              if (editTextTextPersonName2.getText() != null){
                  if (editTextTextPersonName3.getText() != null){
                      if (editTextTextPersonName3.getText() != null){
                          if (editTextTextPersonName4.getText() != null){
                              if (editTextTextPersonName5.getText() != null){
                                  if (editTextTextPersonName6.getText() != null){
                                      intent.putExtra("1", editTextTextPersonName1.getText().toString() );
                                      intent.putExtra("2", editTextTextPersonName2.getText() .toString());
                                      intent.putExtra("3", editTextTextPersonName3.getText().toString() );
                                      intent.putExtra("4", editTextTextPersonName4.getText().toString() );
                                      intent.putExtra("5", editTextTextPersonName5.getText().toString() );
                                      intent.putExtra("6", editTextTextPersonName6.getText().toString() );
                                      intent.putExtra("7", editTextTextPersonName7.getText().toString() );
                                      startActivity(intent);
                                  }else {
                                      Toast.makeText(this,"empty fields",Toast.LENGTH_SHORT);
                                  }
                              }else {
                                  Toast.makeText(this,"empty fields",Toast.LENGTH_SHORT);
                              }
                          }else {
                              Toast.makeText(this,"empty fields",Toast.LENGTH_SHORT);
                          }
                      }else {
                          Toast.makeText(this,"empty fields",Toast.LENGTH_SHORT);
                      }
                  }else {
                      Toast.makeText(this,"empty fields",Toast.LENGTH_SHORT);
                  }
              }else {
                  Toast.makeText(this,"empty fields",Toast.LENGTH_SHORT);
              }
       }else {
              Toast.makeText(this,"empty fields",Toast.LENGTH_SHORT);
          }





    }
}